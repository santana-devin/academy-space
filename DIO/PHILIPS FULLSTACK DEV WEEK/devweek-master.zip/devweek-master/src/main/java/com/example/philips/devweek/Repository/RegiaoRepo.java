package com.example.philips.devweek.Repository;

import com.example.philips.devweek.Entity.Regiao;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RegiaoRepo extends JpaRepository<Regiao,Long> {
}
