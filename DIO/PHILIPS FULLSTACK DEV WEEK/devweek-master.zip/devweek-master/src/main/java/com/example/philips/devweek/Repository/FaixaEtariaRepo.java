package com.example.philips.devweek.Repository;

import com.example.philips.devweek.Entity.FaixaEtaria;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FaixaEtariaRepo extends JpaRepository<FaixaEtaria, Long> {
}
